const DEFAULTS = { links: false, richPaste: true, xlsxNumbers: true, prettyMarkdown: true, dropEmpty: true, csvDelimiter: "," };
const saved = document.getElementById("saved");
let timer;

chrome.storage.sync.get(DEFAULTS).then((opts) => {
  for (const [key, value] of Object.entries(opts)) {
    const el = document.getElementById(key);
    if (!el) continue;
    if (el.type === "checkbox") el.checked = value;
    else el.value = value;
  }
});

for (const key of Object.keys(DEFAULTS)) {
  document.getElementById(key).addEventListener("change", (e) => {
    const value = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    chrome.storage.sync.set({ [key]: value });
    saved.classList.add("on");
    clearTimeout(timer);
    timer = setTimeout(() => saved.classList.remove("on"), 1200);
  });
}

document.getElementById("shortcuts").addEventListener("click", () => {
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});
