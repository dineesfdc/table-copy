// Table Copy - injected on demand (activeTab). Defines window.__tcRun and window.__tcToast.
(() => {
  const DEFAULTS = { links: false, richPaste: true, xlsxNumbers: true, prettyMarkdown: true, dropEmpty: true, csvDelimiter: "," };
  const BR = "\u0001"; // in-cell line break marker
  const ARIA_TABLES = '[role="table"],[role="grid"],[role="treegrid"]';
  const ARIA_CELLS = ["cell", "gridcell", "columnheader", "rowheader"];

  // After a right-click or shortcut the pointer is still over the table, so :hover finds it.
  function hoveredElement() {
    const list = document.querySelectorAll(":hover");
    let el = list[list.length - 1] || null;
    while (el && el.shadowRoot) {
      const inner = el.shadowRoot.querySelectorAll(":hover");
      if (!inner.length) break;
      el = inner[inner.length - 1];
    }
    return el;
  }

  window.__tcToast = (message, isError) => toast(message, isError);

  // Returns true when a table was found (or the user was shown the picker).
  window.__tcRun = async (format, quiet) => {
    const table = await resolveTable(quiet);
    if (table === false) return true; // picker cancelled
    if (!table) {
      if (!quiet) toast("No table found on this part of the page. Right-click directly on a table cell.", true);
      return false;
    }
    const opts = await loadOptions();
    const model = extract(table, opts);
    if (!model.rows.length) {
      toast("That table looks empty.", true);
      return true;
    }
    if (format === "xlsx") {
      const file = fileName() + ".xlsx";
      saveBlob(toXlsx(model, opts), file);
      flash(table);
      const cols = Math.max(...model.rows.map((r) => r.length));
      toast(`Saved ${file}: ${model.rows.length} rows × ${cols} columns (check Downloads)`);
      chrome.runtime.sendMessage({ type: "TC_DONE" }).catch(() => {});
      return true;
    }
    const text = { markdown: toMarkdown, csv: toCsv, tsv: toTsv, json: toJson }[format](model, opts);
    // CSV/TSV also carry a real HTML table so Excel, Word and Docs paste into cells.
    const html = opts.richPaste && (format === "csv" || format === "tsv") ? toHtml(model) : null;
    const ok = await copyText(text, html);
    flash(table);
    const name = { markdown: "Markdown", csv: "CSV", tsv: "TSV", json: "JSON" }[format];
    const cols = Math.max(...model.rows.map((r) => r.length));
    if (ok) {
      toast(`Copied as ${name}: ${model.rows.length} rows × ${cols} columns`);
      chrome.runtime.sendMessage({ type: "TC_DONE" }).catch(() => {});
    } else {
      toast("Copy was blocked by the page. Click the page once and try again.", true);
    }
    return true;
  };

  // Returns a table, null when none was found, or false when the user cancelled the picker.
  async function resolveTable(quiet) {
    let table = findTable(hoveredElement()) || findTable(selectionElement());
    if (!table && !quiet) {
      const found = visibleTables();
      if (found.length === 1) table = found[0];
      else if (found.length > 1) {
        table = await pickTable(found);
        if (!table) return false;
      }
    }
    return table;
  }

  // Copies a PNG of the table as it looks on screen. The screenshot itself is taken by the service worker.
  window.__tcImage = async (quiet) => {
    if (window !== window.top) {
      if (!quiet) toast("Image copy works on the main page, not inside embedded frames.", true);
      return false;
    }
    const table = await resolveTable(quiet);
    if (table === false) return true;
    if (!table) {
      if (!quiet) toast("No table found on this part of the page. Right-click directly on a table cell.", true);
      return false;
    }
    table.scrollIntoView({ block: "nearest", inline: "nearest" });
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    await new Promise((r) => setTimeout(r, 150));
    const r = table.getBoundingClientRect();
    const pad = 8;
    const x0 = Math.max(0, r.left - pad), y0 = Math.max(0, r.top - pad);
    const x1 = Math.min(innerWidth, r.right + pad), y1 = Math.min(innerHeight, r.bottom + pad);
    if (x1 - x0 < 10 || y1 - y0 < 10) {
      toast("The table is not visible on screen.", true);
      return true;
    }
    const clipped = r.left < -1 || r.top < -1 || r.right > innerWidth + 1 || r.bottom > innerHeight + 1;
    let res = null;
    try {
      res = await chrome.runtime.sendMessage({
        type: "TC_CAPTURE",
        rect: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 },
        vw: innerWidth
      });
    } catch {}
    if (!res?.ok) {
      toast("Could not capture an image on this page.", true);
      return true;
    }
    const bytes = Uint8Array.from(atob(res.base64), (c) => c.charCodeAt(0));
    const blob = new Blob([bytes], { type: "image/png" });
    let saved = false;
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
    } catch {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "table.png";
      (document.body || document.documentElement).appendChild(a);
      a.click();
      a.remove();
      saved = true;
    }
    flash(table);
    if (clipped) toast("Copied the visible part. The table is bigger than the screen; zoom out (Ctrl and minus) to fit it all.", true);
    else toast(saved ? "Clipboard was blocked, so the image was saved as table.png" : "Copied table as image (PNG)");
    chrome.runtime.sendMessage({ type: "TC_DONE" }).catch(() => {});
    return true;
  };

  function selectionElement() {
    const n = getSelection()?.anchorNode;
    return n ? (n.nodeType === 1 ? n : n.parentElement) : null;
  }

  async function loadOptions() {
    try {
      return { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
    } catch {
      return { ...DEFAULTS };
    }
  }

  // ---------- locate ----------
  function findTable(el) {
    if (!el || !el.closest) return null;
    return el.closest("table") || el.closest(ARIA_TABLES) || cssTableAncestor(el) || gridAncestor(el);
  }

  // Tables made with CSS: div { display: table }
  function cssTableAncestor(el) {
    for (let a = el, i = 0; a && a !== document.documentElement && i < 25; a = a.parentElement, i++) {
      const d = getComputedStyle(a).display;
      if (d === "table" || d === "inline-table") return a;
    }
    return null;
  }

  // Div grids with no roles: a container whose children are rows that all hold the same number of cells.
  function rowsOf(container) {
    let c = container;
    while (c.children.length === 1 && c.children[0].children.length) c = c.children[0];
    return Array.from(c.children).filter((r) => r.checkVisibility?.() !== false);
  }
  function looksLikeGrid(container) {
    const rows = rowsOf(container);
    if (rows.length < 3) return false;
    const freq = {};
    for (const r of rows) freq[r.children.length] = (freq[r.children.length] || 0) + 1;
    const [mode, hits] = Object.entries(freq).sort((a, b) => b[1] - a[1])[0];
    return +mode >= 2 && hits / rows.length >= 0.75;
  }
  function gridAncestor(el) {
    for (let a = el, i = 0; a && a !== document.body && i < 12; a = a.parentElement, i++) {
      if (looksLikeGrid(a)) return a;
    }
    return null;
  }

  // Tables currently on screen (innermost only, so layout tables are skipped).
  function visibleTables() {
    const sel = 'table,[role="table"],[role="grid"],[role="treegrid"]';
    return Array.from(document.querySelectorAll(sel)).filter((t) => {
      if (t.checkVisibility && !t.checkVisibility()) return false;
      const r = t.getBoundingClientRect();
      if (r.width < 60 || r.height < 24) return false;
      if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return false;
      return !t.querySelector(sel);
    });
  }

  // Shown only when the pointer position is unknown and several tables are visible.
  function pickTable(tables) {
    return new Promise((resolve) => {
      const host = document.createElement("div");
      host.setAttribute("data-tc-picker", "");
      host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none";
      const root = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent =
        ".box{position:fixed;border:3px solid #5B5BD6;background:rgba(91,91,214,.14);border-radius:6px;pointer-events:auto;cursor:pointer}" +
        ".box:hover{background:rgba(91,91,214,.32)}" +
        ".tag{position:absolute;left:-3px;top:-30px;background:#5B5BD6;color:#fff;font:600 13px system-ui,sans-serif;padding:4px 10px;border-radius:6px 6px 6px 0}" +
        ".hint{position:fixed;top:16px;left:50%;transform:translateX(-50%);background:#1F2257;color:#fff;font:600 14px system-ui,sans-serif;padding:10px 16px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.3)}";
      root.appendChild(style);
      const finish = (value) => {
        clearTimeout(timer);
        removeEventListener("keydown", onKey, true);
        removeEventListener("scroll", cancel, true);
        host.remove();
        resolve(value);
      };
      const cancel = () => finish(null);
      const onKey = (e) => e.key === "Escape" && cancel();
      const hint = document.createElement("div");
      hint.className = "hint";
      hint.textContent = "Click the table you want to copy (Esc to cancel)";
      root.appendChild(hint);
      tables.forEach((t, i) => {
        const r = t.getBoundingClientRect();
        const box = document.createElement("div");
        box.className = "box";
        box.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
        const tag = document.createElement("div");
        tag.className = "tag";
        tag.textContent = `Table ${i + 1}`;
        box.appendChild(tag);
        box.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); finish(t); });
        root.appendChild(box);
      });
      addEventListener("keydown", onKey, true);
      addEventListener("scroll", cancel, true);
      const timer = setTimeout(cancel, 20000);
      document.documentElement.appendChild(host);
    });
  }

  // ---------- extract ----------
  function extract(table, opts) {
    const model =
      table.tagName === "TABLE"
        ? fromHtmlTable(table, opts)
        : table.matches(ARIA_TABLES)
        ? fromAriaTable(table, opts)
        : /table/.test(getComputedStyle(table).display)
        ? fromCssTable(table, opts)
        : fromGenericGrid(table, opts);
    let rows = model.rows;
    const width = Math.max(0, ...rows.map((r) => r.length));
    rows = rows.map((r) => Array.from({ length: width }, (_, i) => r[i] ?? ""));

    if (opts.dropEmpty) {
      rows = rows.filter((r) => r.some((c) => c !== ""));
      const keep = [];
      for (let c = 0; c < width; c++) if (rows.some((r) => r[c] !== "")) keep.push(c);
      rows = rows.map((r) => keep.map((c) => r[c]));
      model.aligns = keep.map((c) => model.aligns[c] || "");
    }
    return { rows, aligns: model.aligns };
  }

  function fromHtmlTable(table, opts) {
    const grid = [];
    const filled = []; // like grid, but merged cells repeat their value (used for multi-row headers)
    const refs = [];
    const trs = Array.from(table.rows);
    trs.forEach((tr, r) => {
      grid[r] = grid[r] || [];
      refs[r] = refs[r] || [];
      let c = 0;
      for (const cell of tr.cells) {
        while (grid[r][c] !== undefined) c++;
        const rs = Math.max(1, Math.min(cell.rowSpan || 1, trs.length - r));
        const cs = Math.max(1, Math.min(cell.colSpan || 1, 200));
        const value = cellText(cell, opts);
        for (let i = 0; i < rs; i++) {
          grid[r + i] = grid[r + i] || [];
          refs[r + i] = refs[r + i] || [];
          filled[r + i] = filled[r + i] || [];
          for (let j = 0; j < cs; j++) {
            filled[r + i][c + j] = value;
            grid[r + i][c + j] = i === 0 && j === 0 ? value : "";
            if (i === 0 && j === 0) refs[r + i][c + j] = cell;
          }
        }
        c += cs;
      }
    });
    // Leading rows made only of <th> (or inside <thead>) form the header block.
    let headerRows = 0;
    while (
      headerRows < trs.length &&
      (trs[headerRows].parentElement.tagName === "THEAD" ||
        Array.from(trs[headerRows].cells).every((c) => c.tagName === "TH"))
    ) headerRows++;

    let rows = grid.map((r) => Array.from(r, (v) => v ?? ""));
    let bodyStart = Math.min(1, trs.length - 1);
    if (headerRows > 1 && headerRows < trs.length) {
      // Markdown, CSV and JSON only support one header row: merge "Sales" + "Q1" into "Sales / Q1".
      const width = Math.max(...filled.slice(0, headerRows).map((r) => r.length));
      const merged = Array.from({ length: width }, (_, c) => {
        const parts = [];
        for (let r = 0; r < headerRows; r++) {
          const v = filled[r][c];
          if (v && !parts.includes(v)) parts.push(v);
        }
        return parts.join(" / ");
      });
      rows = [merged, ...rows.slice(headerRows)];
      bodyStart = headerRows;
    }
    // Column alignment comes from the first body row (th defaults to centered).
    const alignRow = refs[bodyStart] || refs[0] || [];
    const aligns = alignRow.map((cell) => (cell ? alignOf(cell) : ""));
    return { rows, aligns };
  }

  function fromAriaTable(root, opts) {
    const rows = [];
    const rowEls = Array.from(root.querySelectorAll('[role="row"]')).filter(
      (r) => r.closest(ARIA_TABLES) === root
    );
    for (const row of rowEls) {
      const cells = Array.from(row.querySelectorAll("[role]")).filter(
        (c) => ARIA_CELLS.includes(c.getAttribute("role")) && c.closest('[role="row"]') === row
      );
      rows.push(cells.map((c) => cellText(c, opts)));
    }
    return { rows, aligns: [] };
  }

  function fromCssTable(root, opts) {
    const disp = (e) => getComputedStyle(e).display;
    const owner = (e) => {
      for (let p = e.parentElement; p; p = p.parentElement) if (/^(inline-)?table$/.test(disp(p))) return p;
      return null;
    };
    const rowEls = Array.from(root.querySelectorAll("*")).filter((e) => disp(e) === "table-row" && owner(e) === root);
    const rows = rowEls.map((r) =>
      Array.from(r.children).filter((c) => disp(c) === "table-cell").map((c) => cellText(c, opts))
    );
    return { rows, aligns: [] };
  }

  function fromGenericGrid(container, opts) {
    const rows = rowsOf(container).map((r) =>
      Array.from(r.children).filter((c) => c.checkVisibility?.() !== false).map((c) => cellText(c, opts))
    );
    return { rows, aligns: [] };
  }

  function alignOf(cell) {
    const a = getComputedStyle(cell).textAlign;
    if (a === "center") return "center";
    if (a === "right" || a === "end") return "right";
    return "";
  }

  function cellText(cell, opts) {
    const raw = nodeText(cell, opts);
    const collapsed = raw.replace(/[ \t\r\n\f\u00a0\u200b]+/g, " ");
    return collapsed
      .split(BR)
      .map((s) => s.trim())
      .filter(Boolean)
      .join(BR);
  }

  const BLOCK = new Set(["DIV", "P", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "TR"]);
  function nodeText(node, opts) {
    if (node.nodeType === 3) return node.nodeValue;
    if (node.nodeType !== 1) return "";
    const tag = node.tagName;
    if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE"].includes(tag)) return "";
    if (node.checkVisibility && !node.checkVisibility()) return "";
    if (tag === "BR") return BR;
    if (tag === "IMG") return node.alt || "";
    if (tag === "INPUT") {
      if (node.type === "checkbox" || node.type === "radio") return node.checked ? "☑" : "☐";
      if (node.type === "hidden") return "";
      return node.value || "";
    }
    if (tag === "SELECT") return node.selectedOptions[0]?.textContent || "";
    if (tag === "TEXTAREA") return node.value || "";
    let out = "";
    for (const child of node.childNodes) out += nodeText(child, opts);
    if (tag === "A" && opts.links && node.href && /^https?:/i.test(node.href) && out.trim()) {
      out = `[${out.trim()}](${node.href})`;
    }
    return BLOCK.has(tag) ? BR + out + BR : out;
  }

  // ---------- formats ----------
  function toMarkdown({ rows, aligns }, opts) {
    const esc = (s) => s.replace(/\|/g, "\\|").split(BR).join("<br>");
    const cells = rows.map((r) => r.map(esc));
    const width = cells[0].length;
    const widths = Array.from({ length: width }, (_, c) =>
      opts.prettyMarkdown ? Math.max(3, ...cells.map((r) => r[c].length)) : 3
    );
    const pad = (s, c) => {
      if (!opts.prettyMarkdown) return s;
      const a = aligns[c];
      const gap = widths[c] - s.length;
      if (a === "right") return " ".repeat(gap) + s;
      if (a === "center") return " ".repeat(gap >> 1) + s + " ".repeat(gap - (gap >> 1));
      return s + " ".repeat(gap);
    };
    const line = (r) => "| " + r.map(pad).join(" | ") + " |";
    const sep = widths.map((w, c) => {
      const a = aligns[c];
      const dashes = "-".repeat(Math.max(1, w - (a === "center" ? 2 : a === "right" ? 1 : 0)));
      return a === "center" ? `:${dashes}:` : a === "right" ? `${dashes}:` : dashes;
    });
    return [line(cells[0]), "| " + sep.join(" | ") + " |", ...cells.slice(1).map(line)].join("\n");
  }

  function toCsv({ rows }, opts) {
    const d = opts.csvDelimiter === "\\t" ? "\t" : opts.csvDelimiter || ",";
    const q = (s) => {
      s = s.split(BR).join("\n");
      return /["\n\r]/.test(s) || s.includes(d) || /^\s|\s$/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    return rows.map((r) => r.map(q).join(d)).join("\n");
  }

  function toTsv({ rows }) {
    return rows.map((r) => r.map((s) => s.split(BR).join(" ").replace(/\t/g, " ")).join("\t")).join("\n");
  }

  // ---------- Excel (.xlsx) ----------
  // A workbook is a zip of small XML files. This writes one without any library.
  const CRC = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  const crc32 = (b) => {
    let c = ~0;
    for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8);
    return ~c >>> 0;
  };
  const u16 = (v) => [v & 255, (v >> 8) & 255];
  const u32 = (v) => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];

  function zipFiles(files) {
    const enc = new TextEncoder();
    const parts = [];
    const central = [];
    let offset = 0;
    for (const f of files) {
      const name = enc.encode(f.name);
      const data = enc.encode(f.text);
      const crc = crc32(data);
      const local = Uint8Array.from([
        ...u32(0x04034b50), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21),
        ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)
      ]);
      parts.push(local, name, data);
      central.push(
        Uint8Array.from([
          ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21),
          ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length),
          ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)
        ]),
        name
      );
      offset += local.length + name.length + data.length;
    }
    const cdSize = central.reduce((n, c) => n + c.length, 0);
    const end = Uint8Array.from([
      ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length),
      ...u32(cdSize), ...u32(offset), ...u16(0)
    ]);
    return new Blob([...parts, ...central, end], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });
  }

  const xmlEsc = (v) =>
    v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const colName = (i) => {
    let s = "";
    for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + ((i - 1) % 26)) + s;
    return s;
  };

  // Style ids: 0 general, 1 header, 2 #,##0, 3 #,##0.00, 4 0.00%, 5 $, 6 EUR, 7 GBP
  function parseCell(raw) {
    const text = { text: raw };
    let t = raw.trim();
    if (!t) return text;
    let sign = 1;
    if (/^\(.*\)$/.test(t)) { sign = -1; t = t.slice(1, -1).trim(); }
    if (t[0] === "-" || t[0] === "\u2212") { sign *= -1; t = t.slice(1).trim(); } else if (t[0] === "+") t = t.slice(1).trim();
    let cur = "";
    if ("$€£".includes(t[0])) { cur = t[0]; t = t.slice(1).trim(); }
    if (t[0] === "-") { sign *= -1; t = t.slice(1).trim(); }
    const pct = t.endsWith("%");
    if (pct) t = t.slice(0, -1).trim();
    if (!/^(\d{1,3}(,\d{3})+|\d+)(\.\d+)?$/.test(t)) return text;
    if (/^0\d/.test(t) || t.replace(/\D/g, "").length > 15) return text; // zip codes, long ids
    let n = parseFloat(t.replace(/,/g, "")) * sign;
    let style = t.includes(".") ? 3 : t.includes(",") ? 2 : 0;
    if (pct) { n /= 100; style = 4; }
    else if (cur) style = { "$": 5, "€": 6, "£": 7 }[cur];
    return { num: n, style };
  }

  function toXlsx({ rows }, opts) {
    const widths = rows[0].map((_, c) =>
      Math.min(60, Math.max(8, ...rows.map((r) => (r[c] || "").split(BR).reduce((m, l) => Math.max(m, l.length), 0))) + 2)
    );
    const sheetRows = rows
      .map((r, ri) => {
        const cells = r
          .map((v, ci) => {
            if (v === "") return "";
            const ref = colName(ci) + (ri + 1);
            const p = ri > 0 && opts.xlsxNumbers ? parseCell(v) : { text: v };
            if (p.num !== undefined) return `<c r="${ref}" s="${p.style}"><v>${p.num}</v></c>`;
            const st = ri === 0 ? ' s="1"' : "";
            return `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${xmlEsc(v.split(BR).join("\n"))}</t></is></c>`;
          })
          .join("");
        return `<row r="${ri + 1}">${cells}</row>`;
      })
      .join("");
    const last = colName(rows[0].length - 1) + rows.length;
    const NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    const hdr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
    const sheet =
      `${hdr}<worksheet xmlns="${NS}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>` +
      `<cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("")}</cols>` +
      `<sheetData>${sheetRows}</sheetData><autoFilter ref="A1:${last}"/></worksheet>`;
    const styles =
      `${hdr}<styleSheet xmlns="${NS}"><numFmts count="3">` +
      '<numFmt numFmtId="164" formatCode="&quot;$&quot;#,##0.00"/><numFmt numFmtId="165" formatCode="&quot;€&quot;#,##0.00"/><numFmt numFmtId="166" formatCode="&quot;£&quot;#,##0.00"/></numFmts>' +
      '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>' +
      '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8EAF6"/><bgColor indexed="64"/></patternFill></fill></fills>' +
      '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="8"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
      '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>' +
      [3, 4, 10, 164, 165, 166].map((n) => `<xf numFmtId="${n}" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>`).join("") +
      '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    const R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    const PK = "http://schemas.openxmlformats.org/package/2006/relationships";
    return zipFiles([
      { name: "[Content_Types].xml", text: `${hdr}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>` },
      { name: "_rels/.rels", text: `${hdr}<Relationships xmlns="${PK}"><Relationship Id="rId1" Type="${R}/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: "xl/workbook.xml", text: `${hdr}<workbook xmlns="${NS}" xmlns:r="${R}"><sheets><sheet name="Table" sheetId="1" r:id="rId1"/></sheets></workbook>` },
      { name: "xl/_rels/workbook.xml.rels", text: `${hdr}<Relationships xmlns="${PK}"><Relationship Id="rId1" Type="${R}/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="${R}/styles" Target="styles.xml"/></Relationships>` },
      { name: "xl/worksheets/sheet1.xml", text: sheet },
      { name: "xl/styles.xml", text: styles }
    ]);
  }

  function fileName() {
    return (document.title || "table").replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "-").slice(0, 40) || "table";
  }

  function saveBlob(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    (document.body || document.documentElement).appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  }

  function toHtml({ rows }) {
    const esc = (v) => v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").split(BR).join("<br>");
    const tr = (r, t) => "<tr>" + r.map((c) => `<${t}>${esc(c)}</${t}>`).join("") + "</tr>";
    return (
      '<table border="1" cellspacing="0" cellpadding="4"><thead>' + tr(rows[0], "th") + "</thead><tbody>" +
      rows.slice(1).map((r) => tr(r, "td")).join("") + "</tbody></table>"
    );
  }

  function toJson({ rows }) {
    const seen = {};
    const keys = rows[0].map((h, i) => {
      let k = (h.split(BR).join(" ") || `column_${i + 1}`).trim();
      seen[k] = (seen[k] || 0) + 1;
      return seen[k] > 1 ? `${k}_${seen[k]}` : k;
    });
    const data = rows.slice(1).map((r) =>
      Object.fromEntries(keys.map((k, i) => [k, r[i].split(BR).join("\n")]))
    );
    return JSON.stringify(data, null, 2);
  }

  // ---------- clipboard + feedback ----------
  async function copyText(text, html) {
    // The copy event lets us write plain text and an HTML table to the clipboard together.
    const prev = document.activeElement;
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:0;left:0;opacity:0;pointer-events:none";
    (document.body || document.documentElement).appendChild(ta);
    ta.select();
    const onCopy = (e) => {
      e.clipboardData.setData("text/plain", text);
      if (html) e.clipboardData.setData("text/html", html);
      e.preventDefault();
    };
    document.addEventListener("copy", onCopy, true);
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {}
    document.removeEventListener("copy", onCopy, true);
    ta.remove();
    prev?.focus?.();
    if (ok) return true;
    try {
      if (html && window.ClipboardItem) {
        await navigator.clipboard.write([
          new ClipboardItem({
            "text/plain": new Blob([text], { type: "text/plain" }),
            "text/html": new Blob([html], { type: "text/html" })
          })
        ]);
      } else {
        await navigator.clipboard.writeText(text);
      }
      return true;
    } catch {
      return false;
    }
  }

  function flash(el) {
    const prev = [el.style.outline, el.style.outlineOffset];
    el.style.outline = "3px solid #5B5BD6";
    el.style.outlineOffset = "2px";
    setTimeout(() => {
      el.style.outline = prev[0];
      el.style.outlineOffset = prev[1];
    }, 700);
  }

  let toastHost = null;
  function toast(message, isError = false) {
    toastHost?.remove();
    toastHost = document.createElement("div");
    toastHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647";
    const root = toastHost.attachShadow({ mode: "closed" });
    const box = document.createElement("div");
    box.setAttribute("role", "status");
    box.textContent = (isError ? "⚠ " : "✓ ") + message;
    box.style.cssText =
      "font:600 14px/1.4 system-ui,sans-serif;color:#fff;padding:12px 16px;border-radius:10px;" +
      `background:${isError ? "#C92A2A" : "#1F2257"};box-shadow:0 8px 24px rgba(0,0,0,.25);max-width:340px`;
    root.appendChild(box);
    (document.body || document.documentElement).appendChild(toastHost);
    setTimeout(() => toastHost?.remove(), 2600);
  }
})();
