// Table Copy - service worker. Builds the right-click menu and injects the converter on demand.
// Uses activeTab + scripting, so no broad host permission is needed.
const TITLES = {
  markdown: "Copy table as Markdown",
  csv: "Copy table as CSV",
  tsv: "Copy table as TSV (Excel / Google Sheets)",
  json: "Copy table as JSON",
  image: "Copy table as image (PNG)",
  xlsx: "Save table as Excel file (.xlsx)"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    for (const [id, title] of Object.entries(TITLES)) {
      chrome.contextMenus.create({
        id: `tc-${id}`,
        title,
        contexts: ["all"]
      });
    }
  });
});

// frameId null = every frame (keyboard shortcut); otherwise only the clicked frame.
async function handleCopy(tabId, frameId, format, source) {
  const target = frameId == null ? { tabId, allFrames: true } : { tabId, frameIds: [frameId] };
  const quiet = source === "shortcut";
  try {
    await chrome.scripting.executeScript({ target, files: ["content.js"] });
    const results = await chrome.scripting.executeScript({
      target,
      func: format === "image" ? (f, q) => window.__tcImage(q) : (f, q) => window.__tcRun(f, q),
      args: [format, quiet]
    });
    if (quiet && !results.some((r) => r.result)) {
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        func: () => window.__tcToast("No table under the cursor. Hover a table and try again.", true)
      });
    }
  } catch (e) {
    // Restricted pages (chrome://, the Web Store) cannot be scripted.
    chrome.action.setBadgeBackgroundColor({ color: "#C92A2A", tabId });
    chrome.action.setBadgeText({ text: "!", tabId });
    setTimeout(() => chrome.action.setBadgeText({ text: "", tabId }).catch(() => {}), 1800);
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id || !String(info.menuItemId).startsWith("tc-")) return;
  handleCopy(tab.id, info.frameId ?? 0, String(info.menuItemId).slice(3), "menu");
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (!tab?.id) return;
  const format = { "copy-csv": "csv", "copy-image": "image" }[command] || "markdown";
  handleCopy(tab.id, null, format, "shortcut");
});

// Screenshot of the visible tab, cropped to the table. activeTab allows captureVisibleTab.
async function capture(tab, { rect, vw }) {
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
  const k = bmp.width / vw;
  const sx = Math.round(rect.x * k), sy = Math.round(rect.y * k);
  const sw = Math.max(1, Math.min(bmp.width - sx, Math.round(rect.w * k)));
  const sh = Math.max(1, Math.min(bmp.height - sy, Math.round(rect.h * k)));
  const canvas = new OffscreenCanvas(sw, sh);
  canvas.getContext("2d").drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
  const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: "image/png" })).arrayBuffer());
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return { ok: true, base64: btoa(bin) };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "TC_CAPTURE" && sender.tab) {
    capture(sender.tab, msg).then(sendResponse, () => sendResponse({ ok: false }));
    return true;
  }
  if (msg?.type !== "TC_DONE" || !sender.tab?.id) return;
  const tabId = sender.tab.id;
  chrome.action.setBadgeBackgroundColor({ color: "#12B886", tabId });
  chrome.action.setBadgeText({ text: "✓", tabId });
  setTimeout(() => chrome.action.setBadgeText({ text: "", tabId }).catch(() => {}), 1800);
});
